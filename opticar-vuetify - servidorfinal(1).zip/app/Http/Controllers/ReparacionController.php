<?php

namespace App\Http\Controllers;

use App\DetalleReparacion;
use Illuminate\Http\Request;
use App\Reparacion;
use App\Http\Resources\Reparacion as ReparacionResource;
use Illuminate\Support\Facades\DB;



class ReparacionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.   
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */

   
    public function store(Request $request)
    {
        $reparacion = new Reparacion();

        $reparacion->rut_cliente = $request->rutboleta;
        $reparacion->monto_total = $request->totalboleta;
        $reparacion->patente_vehiculo = $request->patentevehiculo;

        if ($reparacion->save()) {
            // $productos = json_decode($request->productos);
            $productos=$request->productos;
            $object = json_decode(json_encode($productos), FALSE);
            foreach ($object as $producto) {
                $dc = new DetalleReparacion();
                $dc->id_reparacion = $reparacion->id;
                $dc->repuesto = $producto->resp;
                $dc->costo = $producto->cost;
                $dc->observacion = $producto->obs;
                $dc->mantencion = $producto->mant;
                $dc->estado = 'Reposo';
                $dc->save();
            }
            return;
        }
    }
    public function detalle($id){
        $sql="SELECT * FROM detalle_reparacion where id_reparacion='$id'";
        $data = DB::select($sql);
        return compact('data');
    }
    public function getReparaciones(){
        
        return  new ReparacionResource(Reparacion::all()->where('estado','=',0));

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }
    public function updateReparacion(Request $request,$id){
        $detallereparacion = DetalleReparacion::find($id);
        $detallereparacion->estado=$request->estado;
        $detallereparacion->save();
        return response()->json($detallereparacion);

    
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
