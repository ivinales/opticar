<template>
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-md-8">
        <v-data-table :headers="headers" :items="historial" class="elevation-1">
          <template v-slot:items="props">
            <td>{{ props.item.rut_cliente }}</td>
            <td>{{ props.item.monto_total }}</td>
            <td>{{ props.item.created_at }}</td>
            <td class="layout px-0">
              <v-icon small class="mr-2" @click="VerDetalleCotizacion(props.item.id)">edit</v-icon>
            </td>
          </template>
          <template v-slot:no-data></template>
        </v-data-table>
      </div>
    </div>
    <v-dialog v-model="dialog" max-width="1000px">
      <v-card>
        <v-card-title>
          <span class="headline">Detalle de Boleta</span>
        </v-card-title>

        <v-card-text>
          <v-container grid-list-md>
            <v-data-table :headers="headers2" :items="resultado" class="elevation-1">
              <template v-slot:items="props2">
                <td>{{ props2.item.repuesto  }}</td>
                <td>{{ props2.item.mantencion  }}</td>
                <td>{{ props2.item.costo  }}</td>
                <td>{{ props2.item.observacion  }}</td>
                
                
              </template>
              <template v-slot:no-data></template>
            </v-data-table>
          </v-container>
        </v-card-text>

        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn color="blue darken-1" flat @click="dialog=false">Cancelar</v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
  </div>
</template>

<script>
export default {
    props: ['rut'],
  mounted() {
    console.log("Historial montado.");
  },
  data: function() {
    return {
      headers: [
        { text: "RUT", value: "rut" },
        { text: "MONTO", value: "monto" },
        { text: "FECHA", value: "fecha" },
        { text: "", value: "" }
      ],
      headers2:[
        { text: "REPUESTO", value: "respuesto" },
        { text: "MANTENCION", value: "mantencion" },
        { text: "COSTO", value: "costo" },
        { text: "OBSERVACION", value: "observacion" },
        
      ],
      historial: [],
      validacion: true,
      listaMapa: null,
      prueba: true,
      contenido: null,
      dialog: false,
      restulado: null,
      repuesto: null,
      mantencion: null,
      costo: null,
      observacion: null,
      resultado: []
    };
  },
  created: function() {
    // this.$bus.$emit("cambiarTextoTitulo", "Lista de Historial");
    //        this.usuario=User.nameUser();
    // this.obtenerHistorial(this.usuario.rut);
    this.obtenerHistorial(this.rut);

  },
  methods: {
    VerDetalleCotizacion(id) {
      // this.verItem = item;
      this.dialog = true;
      axios
        .request({
          url: `/historial/detalleboleta/${id}`,
          method: "get"
        })
        .then(res => {
          this.resultado = res.data.data;
          if (this.resultado) {

            // this.repuesto = this.resultado[0].repuesto;
            // this.mantencion = this.resultado[0].mantencion;
            // this.costo = this.resultado[0].costo;
            // this.observacion = this.resultado[0].observacion;
          } else {
            console.log("negativo");
          }
        })
        .catch(error => {
          console.log(error);
        });
    },
    obtenerHistorial(id) {
      console.log("buscando historial",id);

      axios
        .get(`/historial/buscar/${id}`)
        .then(res => {
          this.historial = res.data.data;
          console.log("respuesta", res.data.data);
          //   this.listaMapa = res.data.data;
          // console.log(res.data.data);
          // console.log(res);
        })
        .catch(error => {
        //   this.errors = error.response.data.errors;
          console.log(error)
        });
    }
  }
};
</script>
