<?php $__env->startComponent('mail::layout'); ?>
    
    <?php $__env->slot('header'); ?>
        <?php $__env->startComponent('mail::header', ['url' => config('app.url')]); ?>
            Wonderful Company
        <?php echo $__env->renderComponent(); ?>
    <?php $__env->endSlot(); ?>
Dear <?php echo e($user->name); ?>



<h2><?php echo e($new_arrival->title); ?></h2>

<p><?php echo e($new_arrival->body); ?></p>

click on the link below to see more


<?php $__env->startComponent('mail::button', ['url' => url('/')]); ?>
View Arrival
<?php echo $__env->renderComponent(); ?>

Regards,<br>
Wonderful Company Support Team


    <?php $__env->slot('footer'); ?>
        <?php $__env->startComponent('mail::footer'); ?>
            <!-- footer here -->
        <?php echo $__env->renderComponent(); ?>
    <?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?><?php /**PATH C:\Users\Ian\Desktop\opticar-vuetify\resources\views/emails/newarrivals.blade.php ENDPATH**/ ?>