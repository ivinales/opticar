<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="<?php echo e(mix('/css/app.css')); ?>">
</head>
<body>
    <div id="app">
        <v-app>
        <example-component/>
        </v-app>
    </div>
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
</body>
</html><?php /**PATH C:\Users\Ian\Desktop\opticar-vuetify\resources\views/funciona.blade.php ENDPATH**/ ?>