<?php $__env->startSection('contenido'); ?>

 <?php if(Auth::check()): ?>
            <?php if(Auth::user()->idrol == 1): ?>
               
            <template v-if="menu==0">
            
            </template>

             <template v-if="menu==6">
              <cliente-component/>
            </template>
            
            <template v-if="menu==21">
              <vehiculo-component/>
            </template>
            
            
            
            <template v-if="menu==11">
              <taller-component identificador="<?php echo e(Auth::user()->id); ?>"/>
            </template>
            <template v-if="menu==30">
              <v-app>
              <new-arrivals/>
            </v-app>
            </template>

            <?php elseif(Auth::user()->idrol == 2): ?>
            <template v-if="menu==0">
            
            </template>

            <template v-if="menu==1">
                <categoria-component/>
            </template>

            <template v-if="menu==2">
                <producto-component/>
            </template>

            <template v-if="menu==5">
                
            </template>
            <template v-if="menu==11">
              <taller-component/>
          </template>
          <template v-if="menu==13">
           <arbol-component/>
        </template>
        <template v-if="menu==14">
          Fallas a futuro
      </template>
      <template v-if="menu==15">
        Presupuesto
    </template>
    <template v-if="menu==16">
     historial
  </template>
  <template v-if="menu==17">
    reparaciones
 </template>
 <template v-if="menu==20">
   
   <v-app>
  <cotizacion-component/>
</v-app>
</template>
<template v-if="menu==21">
  <v-app>
 <reparacion-component/>
</v-app>
</template>
<template v-if="menu==22">
  <v-app>
 <historial-component rut="<?php echo e(Auth::user()->num_documento); ?>"> </historial-component>
</v-app>
</template>

            
            <?php elseif(Auth::user()->idrol == 3): ?>
            
            
           
            <template v-if="menu==11">
              alert("ax");
              taleres
          </template>
          <template v-if="menu==13">
           <arbol-component/>
        </template>
        <template v-if="menu==14">
          Fallas a futuro
      </template>
      <template v-if="menu==15">
        Presupuesto
    </template>
    <template v-if="menu==16">
     historial
  </template>
  <template v-if="menu==17">
    reparaciones
 </template>
            <?php else: ?>

            <?php endif; ?>

<?php endif; ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ian\Desktop\opticar-vuetify\resources\views/contenido/contenido.blade.php ENDPATH**/ ?>