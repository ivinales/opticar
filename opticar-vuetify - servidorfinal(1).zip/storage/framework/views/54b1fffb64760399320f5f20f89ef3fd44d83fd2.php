<div class="sidebar">
    <nav class="sidebar-nav">
        <ul class="nav">
            <li @click="menu=0" class="nav-item" >
                <a class="nav-link active" href="#"><i class="icon-speedometer"></i> Dashbord</a>
            </li>
            <li class="nav-title">
                Menú
            </li>

           
            <li @click="menu=1" class="nav-item">
                <a class="nav-link" href="#"><i class="fa fa-list"></i> Categorías</a>
            </li>
            
            <li @click="menu=2" class="nav-item">
                <a class="nav-link" href="#"><i class="fa fa-tasks"></i> Productos</a>
            </li>
           
            <li @click="menu=5" class="nav-item">
                <a class="nav-link" href="#"><i class="fa fa-suitcase"></i> Ventas</a>
            </li>

            
            <li @click="menu=13" class="nav-item">
                <a class="nav-link" href="#"><i class="fa fa-users"></i> Arbol</a>
            </li>
            <li @click="menu=20" class="nav-item">
                <a class="nav-link" href="#"><i class="fa fa-users"></i> Presupuesto</a>
            </li>
            <li @click="menu=21" class="nav-item">
                <a class="nav-link" href="#"><i class="fa fa-users"></i> Reparacion</a>
            </li>
            <li @click="menu=22" class="nav-item">
                <a class="nav-link" href="#"><i class="fa fa-users"></i> Historial</a>
            </li>
            
        </ul>
    </nav>
    <button class="sidebar-minimizer brand-minimizer" type="button"></button>
</div><?php /**PATH C:\Users\Ian\Desktop\opticar-vuetify\resources\views/plantilla/sidebarmecanico.blade.php ENDPATH**/ ?>