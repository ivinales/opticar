<?php echo e($slot); ?>

<?php /**PATH C:\Users\Ian\Desktop\opticar-vuetify\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>