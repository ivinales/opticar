<!DOCTYPE html>
<html lang="es-ES">
<head>
    <meta charset="utf-8">
</head>
<body>
<h2>Â¡Curso Laravel!</h2>

<div>
   Â¡Bienvenido al sitio Web de <?php echo $name; ?> !
</div>

</body>
</html><?php /**PATH C:\Users\Ian\Desktop\opticar-vuetify\resources\views/emails/welcome.blade.php ENDPATH**/ ?>